const course = document.querySelector('#course');
const status = document.querySelector('#status');
const refreshButton = document.querySelector('#refresh');
const currentButton = document.querySelector('#export-current');
const batchButton = document.querySelector('#export-batch');
const zipButton = document.querySelector('#download-zip');
const lessonList = document.querySelector('#lesson-list');
let detected = null;
let busy = false;
const states = new Map();

async function activeTab() {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  return tab;
}

function setBusy(value) {
  busy = value;
  refreshButton.disabled = value;
  currentButton.disabled = value;
  batchButton.disabled = value;
  zipButton.disabled = value || !lessonList.children.length;
}

async function refresh() {
  if (busy) return;
  course.textContent = '正在偵測目前頁面…';
  try {
    const tab = await activeTab();
    detected = await chrome.runtime.sendMessage({ type: 'DETECT_COURSE', tabId: tab.id });
    if (detected.error) throw new Error(detected.error);
    if (!detected.supported) {
      course.textContent = '這不是 PressPlay 課程單元頁。請切到要處理的課程影片。';
      batchButton.disabled = true;
      return;
    }
    course.innerHTML = `<strong>${escapeHtml(detected.title)}</strong><br><span>課程 ID：${escapeHtml(detected.courseId)}</span><br><b>已偵測到 ${detected.urls.length} 個本課程單元</b>`;
    batchButton.disabled = detected.urls.length < 2;
    renderDetectedLessons(detected.urls);
  } catch (error) {
    course.textContent = `無法偵測：${error.message}`;
  }
}

function escapeHtml(value) {
  return String(value).replace(/[&<>'"]/g, (char) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', "'": '&#39;', '"': '&quot;' })[char]);
}

refreshButton.addEventListener('click', refresh);
currentButton.addEventListener('click', async () => {
  setBusy(true); status.textContent = '正在讀取並下載 VTT…';
  try {
    const tab = await activeTab();
    const result = await chrome.runtime.sendMessage({ type: 'EXPORT_TAB', tabId: tab.id });
    if (!result.itemCount) throw new Error(result.error || '找不到逐字稿。');
    status.textContent = `已下載 VTT：${result.itemCount} 段`;
  } catch (error) { status.textContent = error.message; }
  setBusy(false);
});

batchButton.addEventListener('click', async () => {
  await refresh();
  if (!detected?.supported || detected.urls.length < 2) {
    status.textContent = '請先展開課程章節後重新偵測。';
    return;
  }
  setBusy(true); status.textContent = `準備匯出 ${detected.urls.length} 個單元…`;
  try {
    const tab = await activeTab();
    const result = await chrome.runtime.sendMessage({ type: 'BATCH_EXPORT', lessons: detected.urls });
    if (result.error) throw new Error(result.error);
    renderLessons(result.lessons);
    status.textContent = `已收集 ${result.completed}/${result.total} 個 VTT；可逐檔下載或下載 ZIP。`;
  } catch (error) { status.textContent = error.message; }
  setBusy(false);
  refresh();
});

function renderLessons(lessons) {
  lessonList.innerHTML = `<h2>已收集字幕</h2>${lessons.map((lesson, index) => `<div class="lesson done"><span class="lesson-order">${String(lesson.order + 1).padStart(2, '0')}</span><span class="lesson-title">${escapeHtml(lesson.title)}</span><button data-index="${index}">VTT</button></div>`).join('')}`;
  zipButton.disabled = !lessons.length;
}

function renderDetectedLessons(lessons) {
  if (!lessons.length) { lessonList.innerHTML = ''; return; }
  const visibleLessons = lessons.map((lesson, index) => ({ lesson, index, state: states.get(lesson.url) || { status: 'pending' } }))
    .filter(({ state }) => state.status !== 'skipped');
  lessonList.innerHTML = `<h2>課程目錄</h2>${visibleLessons.map(({ lesson, index, state }) => {
    const label = { pending: '待收集', collecting: '收集中', done: '完成', failed: '找不到字幕', skipped: '已略過' }[state.status];
    const retry = state.status === 'failed' ? `<button data-action="retry" data-index="${index}" title="重新偵測">↻</button>` : '';
    const skip = state.status !== 'collecting' ? `<button data-action="skip" data-index="${index}" title="從本次清單略過">×</button>` : '';
    return `<div class="lesson ${state.status}"><span class="lesson-order">${String(index + 1).padStart(2, '0')}</span><span class="lesson-title">${escapeHtml(lesson.title)}</span><i>${label}</i>${retry}${skip}</div>`;
  }).join('')}`;
  zipButton.disabled = true;
}

lessonList.addEventListener('click', async (event) => {
  const action = event.target.dataset.action;
  if (action) {
    const lesson = detected?.urls[Number(event.target.dataset.index)];
    if (!lesson) return;
    event.target.disabled = true;
    if (action === 'retry') {
      const result = await chrome.runtime.sendMessage({ type: 'RETRY_LESSON', lesson: { ...lesson, order: Number(event.target.dataset.index) } });
      if (result.error) status.textContent = result.error;
    } else if (action === 'skip') {
      await chrome.runtime.sendMessage({ type: 'SKIP_LESSON', url: lesson.url });
    }
    event.target.disabled = false;
    return;
  }
  const index = event.target.dataset.index;
  if (index === undefined) return;
  event.target.disabled = true;
  const result = await chrome.runtime.sendMessage({ type: 'DOWNLOAD_BATCH_ONE', index: Number(index) });
  if (result.error) status.textContent = result.error;
  else status.textContent = '已下載一個 VTT。';
  event.target.disabled = false;
});

zipButton.addEventListener('click', async () => {
  zipButton.disabled = true;
  status.textContent = '正在建立 ZIP…';
  const result = await chrome.runtime.sendMessage({ type: 'DOWNLOAD_BATCH_ZIP' });
  status.textContent = result.error ? result.error : `已下載 ZIP（${result.count} 個 VTT）。`;
  zipButton.disabled = false;
});

chrome.runtime.onMessage.addListener((message) => {
  if (message.type === 'LESSON_PROGRESS') {
    states.set(message.url, { status: message.status, itemCount: message.itemCount, message: message.message });
    if (detected?.urls) renderDetectedLessons(detected.urls);
  }
  if (message.type === 'BATCH_PROGRESS') {
    status.textContent = message.error
      ? `略過一頁：${message.error}`
      : `已完成 ${message.completed}/${message.total}：${message.title}`;
  }
});
chrome.tabs.onActivated.addListener(refresh);
chrome.tabs.onUpdated.addListener((_tabId, info) => { if (info.status === 'complete') refresh(); });
refresh();
