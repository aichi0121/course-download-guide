const status = document.querySelector('#status');
const currentButton = document.querySelector('#export-current');
const batchButton = document.querySelector('#export-batch');

function setBusy(busy) {
  currentButton.disabled = busy;
  batchButton.disabled = busy;
}

async function activeTab() {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  return tab;
}

currentButton.addEventListener('click', async () => {
  setBusy(true); status.textContent = '正在讀取並下載…';
  try {
    const tab = await activeTab();
    const result = await chrome.runtime.sendMessage({ type: 'EXPORT_TAB', tabId: tab.id });
    if (!result.itemCount) throw new Error(result.error || '找不到逐字稿。');
    status.textContent = `已下載 VTT：${result.itemCount} 段`;
  } catch (error) { status.textContent = error.message; }
  setBusy(false);
});

batchButton.addEventListener('click', async () => {
  setBusy(true); status.textContent = '正在掃描課程單元…';
  try {
    const tab = await activeTab();
    const { urls, error } = await chrome.runtime.sendMessage({ type: 'COLLECT_COURSE_URLS', tabId: tab.id });
    if (error) throw new Error(error);
    if (urls.length < 2) throw new Error('只找到目前單元。請先展開右側所有課程章節，再按批次匯出。');
    status.textContent = `已找到 ${urls.length} 個單元，開始匯出…`;
    const result = await chrome.runtime.sendMessage({ type: 'BATCH_EXPORT', urls, tabId: tab.id, originalUrl: tab.url });
    status.textContent = `完成：${result.completed}/${result.total} 個單元`;
  } catch (error) { status.textContent = error.message; }
  setBusy(false);
});

chrome.runtime.onMessage.addListener((message) => {
  if (message.type === 'BATCH_PROGRESS') {
    status.textContent = message.error
      ? `略過一頁：${message.error}`
      : `已完成 ${message.completed}/${message.total}：${message.title}`;
  }
});
