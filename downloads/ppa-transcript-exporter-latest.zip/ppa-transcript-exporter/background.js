function safeName(value) {
  return (value || '未命名單元').replace(/[\\/:*?"<>|]/g, ' ').replace(/\s+/g, ' ').trim().slice(0, 100);
}

let lastBatch = [];
const lessonStates = new Map();

async function downloadTranscript(result, index) {
  if (!result?.text) throw new Error('此頁找不到逐字稿。請確認已開啟播放器右側的逐字稿面板。');
  const prefix = String(index + 1).padStart(3, '0');
  const filename = `${prefix} ${safeName(result.title)}.vtt`;
  await chrome.downloads.download({
    url: `data:text/plain;charset=utf-8,${encodeURIComponent(result.text)}`,
    filename,
    saveAs: false,
    conflictAction: 'uniquify'
  });
}

// 播放器逐字稿位於 iframe；這個函式會被注入每一個可存取的框架中。
async function readTranscriptFromFrame(fallbackTitle) {
  const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));
  const vttTime = (value) => {
    const total = Math.max(0, Number(value) || 0);
    const hours = Math.floor(total / 3600);
    const minutes = Math.floor((total % 3600) / 60);
    const seconds = Math.floor(total % 60);
    const milliseconds = Math.floor((total % 1) * 1000);
    return `${String(hours).padStart(2, '0')}:${String(minutes).padStart(2, '0')}:${String(seconds).padStart(2, '0')}.${String(milliseconds).padStart(3, '0')}`;
  };
  const extract = () => {
    const items = [...document.querySelectorAll('.vjs-transcript-item')];
    const cues = items.map((item, index) => {
      const start = Number(item.dataset.startTime) || 0;
      const nextStart = Number(items[index + 1]?.dataset.startTime);
      const end = Number(item.dataset.endTime);
      const finish = Number.isFinite(end) ? end : (Number.isFinite(nextStart) ? nextStart : start + 3);
      const text = item.innerText.replace(/\u00a0/g, ' ').replace(/^\s*\d{1,2}:\d{2}(?::\d{2})?\s*/, '').trim();
      return text ? `${vttTime(start)} --> ${vttTime(Math.max(finish, start + 0.001))}\n${text}` : '';
    }).filter(Boolean);
    return { itemCount: cues.length, text: cues.length ? `WEBVTT\n\n${cues.join('\n\n')}\n` : '' };
  };
  const deadline = Date.now() + 15000;
  let transcript = extract();
  while (!transcript.itemCount && Date.now() < deadline) {
    await sleep(400);
    transcript = extract();
  }
  const title = (document.querySelector('h1')?.innerText || fallbackTitle || '未命名單元')
    .replace(/[\\/:*?"<>|]/g, ' ').replace(/\s+/g, ' ').trim().slice(0, 100);
  return { ...transcript, title };
}

async function extractFromTab(tabId) {
  const tab = await chrome.tabs.get(tabId);
  const frameResults = await chrome.scripting.executeScript({
    target: { tabId, allFrames: true },
    func: readTranscriptFromFrame,
    args: [tab.title]
  });
  const candidates = frameResults.map(({ result }) => result).filter(Boolean);
  return candidates.sort((a, b) => b.itemCount - a.itemCount)[0] || { itemCount: 0, text: '', title: tab.title };
}

async function collectCourseUrls(tabId) {
  const tab = await chrome.tabs.get(tabId);
  const match = new URL(tab.url).pathname.match(/^(\/project\/[^/]+)\/articles\//);
  if (!match) throw new Error('請在要匯出的課程單元頁啟動批次功能。');
  const coursePath = match[1];
  const results = await chrome.scripting.executeScript({
    target: { tabId },
    func: (path) => {
      const seen = new Set();
      return [...document.querySelectorAll('[data-target]')].flatMap((row) => {
        const id = row.dataset.target;
        const title = row.querySelector('.article-card-header')?.innerText?.replace(/\s+/g, ' ').trim() || '';
        // 只取課程目錄中的編號單元，不混入課前文章、推薦內容或外部文章。
        if (!id || !/^\d+-\d+\s/.test(title) || seen.has(id)) return [];
        seen.add(id);
        return [{ url: `${location.origin}${path}/articles/${id}`, title }];
      });
    },
    args: [coursePath]
  });
  return results[0]?.result || [];
}

async function detectCourse(tabId) {
  const tab = await chrome.tabs.get(tabId);
  const match = new URL(tab.url).pathname.match(/^(\/project\/([^/]+))\/articles\//);
  if (!match) return { supported: false };
  const titleResult = await chrome.scripting.executeScript({
    target: { tabId },
    func: () => document.querySelector('h1')?.innerText?.trim() || document.title
  });
  const urls = await collectCourseUrls(tabId);
  return {
    supported: true,
    title: titleResult[0]?.result || tab.title,
    courseId: match[2],
    urls
  };
}

async function waitForLoaded(tabId) {
  const initial = await chrome.tabs.get(tabId);
  if (initial.status === 'complete') {
    await new Promise((resolve) => setTimeout(resolve, 1500));
    return;
  }
  return new Promise((resolve) => {
    const listener = (changedId, info) => {
      if (changedId === tabId && info.status === 'complete') {
        chrome.tabs.onUpdated.removeListener(listener);
        setTimeout(resolve, 1500);
      }
    };
    chrome.tabs.onUpdated.addListener(listener);
  });
}

async function exportOne(tabId, index) {
  const result = await extractFromTab(tabId);
  await downloadTranscript(result, index);
  return result;
}

async function batchCollect(lessons) {
  let completed = 0;
  const failures = [];
  const captured = [];
  const workerWindow = await chrome.windows.create({ url: lessons[0].url, type: 'popup', state: 'minimized', focused: false });
  const workerTabId = workerWindow.tabs[0].id;
  for (let index = 0; index < lessons.length; index += 1) {
    try {
      lessonStates.set(lessons[index].url, { status: 'collecting' });
      chrome.runtime.sendMessage({ type: 'LESSON_PROGRESS', url: lessons[index].url, status: 'collecting' });
      if (index) await chrome.tabs.update(workerTabId, { url: lessons[index].url });
      await waitForLoaded(workerTabId);
      const result = await extractFromTab(workerTabId);
      if (!result.itemCount) throw new Error('未找到逐字稿');
      completed += 1;
      captured.push({ ...result, title: lessons[index].title || result.title, sourceUrl: lessons[index].url, order: index });
      lessonStates.set(lessons[index].url, { status: 'done', itemCount: result.itemCount });
      chrome.runtime.sendMessage({ type: 'LESSON_PROGRESS', url: lessons[index].url, status: 'done', itemCount: result.itemCount });
      chrome.runtime.sendMessage({ type: 'BATCH_PROGRESS', completed, total: lessons.length, title: lessons[index].title });
    } catch (error) {
      failures.push({ ...lessons[index], message: error.message, order: index });
      lessonStates.set(lessons[index].url, { status: 'failed', message: error.message });
      chrome.runtime.sendMessage({ type: 'LESSON_PROGRESS', url: lessons[index].url, status: 'failed', message: error.message });
      chrome.runtime.sendMessage({ type: 'BATCH_PROGRESS', completed, total: lessons.length, error: `${lessons[index].title}：${error.message}` });
    }
  }
  await chrome.windows.remove(workerWindow.id);
  lastBatch = captured;
  return { completed, total: lessons.length, failures, lessons: captured.map((item) => ({ title: item.title, itemCount: item.itemCount, order: item.order })) };
}

async function retryLesson(lesson) {
  lessonStates.set(lesson.url, { status: 'collecting' });
  chrome.runtime.sendMessage({ type: 'LESSON_PROGRESS', url: lesson.url, status: 'collecting' });
  const workerWindow = await chrome.windows.create({ url: lesson.url, type: 'popup', state: 'minimized', focused: false });
  try {
    const workerTabId = workerWindow.tabs[0].id;
    await waitForLoaded(workerTabId);
    const result = await extractFromTab(workerTabId);
    if (!result.itemCount) throw new Error('未找到逐字稿');
    const record = { ...result, title: lesson.title || result.title, sourceUrl: lesson.url, order: lesson.order };
    lastBatch = [...lastBatch.filter((item) => item.sourceUrl !== lesson.url), record].sort((a, b) => a.order - b.order);
    lessonStates.set(lesson.url, { status: 'done', itemCount: result.itemCount });
    chrome.runtime.sendMessage({ type: 'LESSON_PROGRESS', url: lesson.url, status: 'done', itemCount: result.itemCount });
    return record;
  } catch (error) {
    lessonStates.set(lesson.url, { status: 'failed', message: error.message });
    chrome.runtime.sendMessage({ type: 'LESSON_PROGRESS', url: lesson.url, status: 'failed', message: error.message });
    throw error;
  } finally {
    await chrome.windows.remove(workerWindow.id);
  }
}

function crc32(bytes) {
  let crc = -1;
  for (const byte of bytes) {
    crc ^= byte;
    for (let bit = 0; bit < 8; bit += 1) crc = (crc >>> 1) ^ (0xEDB88320 & -(crc & 1));
  }
  return (crc ^ -1) >>> 0;
}

function u16(value) { return [value & 255, (value >>> 8) & 255]; }
function u32(value) { return [value & 255, (value >>> 8) & 255, (value >>> 16) & 255, (value >>> 24) & 255]; }
function makeZip(files) {
  const encoder = new TextEncoder();
  const output = [];
  const central = [];
  let offset = 0;
  for (const file of files) {
    const name = encoder.encode(file.name);
    const data = encoder.encode(file.text);
    const crc = crc32(data);
    const local = new Uint8Array([0x50, 0x4b, 3, 4, ...u16(20), ...u16(0), ...u16(0), ...u16(0), ...u16(0), ...u32(crc), ...u32(data.length), ...u32(data.length), ...u16(name.length), ...u16(0), ...name, ...data]);
    output.push(local);
    central.push(new Uint8Array([0x50, 0x4b, 1, 2, ...u16(20), ...u16(20), ...u16(0), ...u16(0), ...u16(0), ...u16(0), ...u32(crc), ...u32(data.length), ...u32(data.length), ...u16(name.length), ...u16(0), ...u16(0), ...u16(0), ...u16(0), ...u32(0), ...u32(offset), ...name]));
    offset += local.length;
  }
  const centralLength = central.reduce((sum, part) => sum + part.length, 0);
  output.push(...central, new Uint8Array([0x50, 0x4b, 5, 6, ...u16(0), ...u16(0), ...u16(files.length), ...u16(files.length), ...u32(centralLength), ...u32(offset), ...u16(0)]));
  return new Blob(output, { type: 'application/zip' });
}

async function downloadBlob(blob, filename) {
  const url = URL.createObjectURL(blob);
  try { await chrome.downloads.download({ url, filename, saveAs: false, conflictAction: 'uniquify' }); }
  finally { setTimeout(() => URL.revokeObjectURL(url), 30000); }
}

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.type === 'DETECT_COURSE') {
    detectCourse(message.tabId).then(sendResponse).catch((error) => sendResponse({ error: error.message }));
    return true;
  }
  if (message.type === 'DOWNLOAD_BATCH_ZIP') {
    const files = lastBatch.map((item) => ({ name: `${String(item.order + 1).padStart(3, '0')} ${safeName(item.title)}.vtt`, text: item.text }));
    downloadBlob(makeZip(files), 'PPA-逐字稿-VTT.zip').then(() => sendResponse({ count: files.length })).catch((error) => sendResponse({ error: error.message }));
    return true;
  }
  if (message.type === 'RETRY_LESSON') {
    retryLesson(message.lesson).then(sendResponse).catch((error) => sendResponse({ error: error.message }));
    return true;
  }
  if (message.type === 'SKIP_LESSON') {
    lessonStates.set(message.url, { status: 'skipped' });
    lastBatch = lastBatch.filter((item) => item.sourceUrl !== message.url);
    chrome.runtime.sendMessage({ type: 'LESSON_PROGRESS', url: message.url, status: 'skipped' });
    sendResponse({});
    return;
  }
  if (message.type === 'DOWNLOAD_BATCH_ONE') {
    const item = lastBatch[message.index];
    if (!item) { sendResponse({ error: '找不到這個字幕檔。請重新批次收集。' }); return; }
    downloadBlob(new Blob([item.text], { type: 'text/vtt;charset=utf-8' }), `${String(item.order + 1).padStart(3, '0')} ${safeName(item.title)}.vtt`).then(() => sendResponse({})).catch((error) => sendResponse({ error: error.message }));
    return true;
  }
  if (message.type === 'COLLECT_COURSE_URLS') {
    collectCourseUrls(message.tabId).then((urls) => sendResponse({ urls })).catch((error) => sendResponse({ error: error.message }));
    return true;
  }
  if (message.type === 'EXPORT_TAB') {
    extractFromTab(message.tabId).then(async (result) => {
      if (!result.itemCount) throw new Error('找不到逐字稿。');
      await downloadTranscript(result, 0);
      return result;
    }).then(sendResponse).catch((error) => sendResponse({ error: error.message }));
    return true;
  }
  if (message.type === 'BATCH_EXPORT') {
    batchCollect(message.lessons).then(sendResponse).catch((error) => sendResponse({ error: error.message }));
    return true;
  }
});

chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: true }).catch(() => {});
