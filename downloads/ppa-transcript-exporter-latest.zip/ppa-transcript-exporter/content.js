const TRANSCRIPT_SELECTOR = '.vjs-transcript-item';

const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

function filenamePart(value) {
  return (value || '未命名單元')
    .replace(/[\\/:*?"<>|]/g, ' ')
    .replace(/\s+/g, ' ')
    .trim()
    .slice(0, 100);
}

function cleanText(item) {
  const raw = item.innerText.replace(/\u00a0/g, ' ').trim();
  // 有些播放器把顯示時間也放進 innerText；資料屬性裡已有正確時間。
  return raw.replace(/^\s*\d{1,2}:\d{2}(?::\d{2})?\s*/, '').trim();
}

function timecode(seconds) {
  const total = Math.max(0, Math.floor(Number(seconds) || 0));
  const mm = String(Math.floor(total / 60)).padStart(2, '0');
  const ss = String(total % 60).padStart(2, '0');
  return `${mm}:${ss}`;
}

function extractTranscript() {
  const items = [...document.querySelectorAll(TRANSCRIPT_SELECTOR)];
  const lines = items.map((item) => {
    const text = cleanText(item);
    return text ? `[${timecode(item.dataset.startTime)}] ${text}` : '';
  }).filter(Boolean);

  const title = filenamePart(
    document.querySelector('h1')?.innerText || document.title.replace(/\s*[-|｜].*$/, '')
  );
  return { title, itemCount: lines.length, text: lines.join('\n') };
}

async function waitForTranscript(timeoutMs = 15000) {
  const end = Date.now() + timeoutMs;
  while (Date.now() < end) {
    const result = extractTranscript();
    if (result.itemCount > 0) return result;
    await sleep(400);
  }
  return extractTranscript();
}

function collectLessonLinks() {
  const urls = [...document.querySelectorAll('a[href]')]
    .map((a) => new URL(a.href, location.href).href)
    .filter((href) => {
      const url = new URL(href);
      return url.origin === location.origin && /\/articles\//.test(url.pathname);
    });
  return [...new Set(urls)];
}

chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  if (message.type === 'EXPORT_CURRENT') {
    waitForTranscript().then(sendResponse);
    return true;
  }
  if (message.type === 'COLLECT_LESSON_LINKS') {
    sendResponse({ urls: collectLessonLinks() });
  }
});
